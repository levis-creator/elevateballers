import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';
import { config } from 'dotenv';
import { readFileSync } from 'fs';
import { join } from 'path';
import { execSync } from 'child_process';

// Load environment variables
config();

// Load production environment variables
const productionEnvPath = join(process.cwd(), '.env.production');
let productionEnv: Record<string, string> = {};
try {
  const envContent = readFileSync(productionEnvPath, 'utf-8');
  envContent.split('\n').forEach(line => {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
      const [key, ...valueParts] = trimmed.split('=');
      const value = valueParts.join('=').replace(/^["']|["']$/g, '');
      productionEnv[key.trim()] = value.trim();
    }
  });
} catch (error) {
  console.error('Warning: Could not read .env.production file');
}

// Get database URLs
let deploymentDbUrl = process.env.DATABASE_URL;
let productionDbUrl = productionEnv.DATABASE_URL || process.env.PRODUCTION_DATABASE_URL;

if (!deploymentDbUrl) {
  throw new Error('DATABASE_URL environment variable is not set (deployment database)');
}

if (!productionDbUrl) {
  throw new Error('PRODUCTION_DATABASE_URL environment variable is not set. Please set it or ensure .env.production exists with DATABASE_URL');
}

// For Supabase pooler connections, we'll handle SSL in the Pool config, not in the URL
// Remove sslmode from URL if it exists and we'll set it properly in Pool config
if (productionDbUrl.includes('pooler.supabase')) {
  productionDbUrl = productionDbUrl.replace(/[?&]sslmode=[^&]*/g, '');
}

if (deploymentDbUrl.includes('supabase') && !deploymentDbUrl.includes('sslmode')) {
  const separator = deploymentDbUrl.includes('?') ? '&' : '?';
  deploymentDbUrl = `${deploymentDbUrl}${separator}sslmode=require`;
}

// Function to try pooler connection if direct connection fails
function getPoolerUrl(url: string): string {
  if (url.includes('supabase') && url.includes(':5432/')) {
    // Replace port 5432 with 6543 and add pgbouncer parameter
    const poolerUrl = url.replace(':5432/', ':6543/');
    const separator = poolerUrl.includes('?') ? '&' : '?';
    return `${poolerUrl}${separator}pgbouncer=true`;
  }
  return url;
}

console.log('🔗 Connecting to databases...');
console.log('📦 Deployment DB:', deploymentDbUrl.replace(/:[^:@]+@/, ':****@'));
console.log('🚀 Production DB:', productionDbUrl.replace(/:[^:@]+@/, ':****@'));

// Create connection pools
// Supabase requires SSL connections
const deploymentPool = new Pool({ 
  connectionString: deploymentDbUrl,
  ssl: deploymentDbUrl.includes('supabase') ? { rejectUnauthorized: false } : undefined
});

// Create Prisma adapters and clients
const deploymentAdapter = new PrismaPg(deploymentPool);
const deploymentDb = new PrismaClient({
  adapter: deploymentAdapter,
  log: ['error'],
});

// Production connection will be set up in main() to handle fallback to pooler
let productionPool: Pool;
let productionAdapter: PrismaPg;
let productionDb: PrismaClient;

// Migration statistics
const stats = {
  users: 0,
  leagues: 0,
  seasons: 0,
  teams: 0,
  staff: 0,
  players: 0,
  teamStaff: 0,
  newsArticles: 0,
  comments: 0,
  matches: 0,
  matchPlayers: 0,
  matchEvents: 0,
  media: 0,
  pageContents: 0,
  siteSettings: 0,
  registrationNotifications: 0,
  gameRules: 0,
  gameStates: 0,
  matchPeriods: 0,
  timeouts: 0,
  substitutions: 0,
  playerPlayingTime: 0,
  jumpBalls: 0,
  eventHistory: 0,
  reportTemplates: 0,
  reportGenerations: 0,
  emailReports: 0,
  errors: 0,
};

// Helper function to migrate data with conflict handling
async function migrateTable<T extends { id: string }>(
  tableName: string,
  getData: () => Promise<T[]>,
  findExisting: (id: string) => Promise<T | null>,
  createRecord: (data: T) => Promise<T>,
  updateRecord?: (data: T) => Promise<T>,
  dependencies?: string[]
) {
  console.log(`\n📦 Migrating ${tableName}...`);
  
  try {
    const data = await getData();
    console.log(`   Found ${data.length} records`);
    
    if (data.length === 0) {
      console.log(`   ⏭️  Skipping ${tableName} (no data)`);
      return;
    }

    let created = 0;
    let updated = 0;
    let skipped = 0;

    for (const record of data) {
      try {
        // Try to find existing record
        const existing = await findExisting(record.id);

        if (existing) {
          if (updateRecord) {
            await updateRecord(record);
            updated++;
          } else {
            skipped++;
          }
        } else {
          await createRecord(record);
          created++;
        }
      } catch (error: any) {
        console.error(`   ❌ Error migrating ${tableName} record ${record.id}:`, error.message);
        stats.errors++;
        
        // If it's a foreign key constraint error, log dependencies
        if (error.message?.includes('Foreign key constraint') || error.message?.includes('violates foreign key')) {
          console.error(`   💡 This might be due to missing dependencies: ${dependencies?.join(', ') || 'unknown'}`);
        }
      }
    }

    console.log(`   ✅ ${tableName}: ${created} created, ${updated} updated, ${skipped} skipped`);
    (stats as any)[tableName] = created + updated;
  } catch (error: any) {
    console.error(`   ❌ Error migrating ${tableName}:`, error.message);
    stats.errors++;
  }
}

async function main() {
  console.log('\n🚀 Starting database migration from deployment to production...\n');

  try {
    // Test connections
    console.log('Testing deployment database connection...');
    try {
      await deploymentDb.$connect();
      await deploymentDb.$queryRaw`SELECT 1`;
      console.log('✅ Deployment database connected');
    } catch (error: any) {
      console.error('❌ Failed to connect to deployment database:', error.message);
      throw error;
    }

    console.log('Testing production database connection...');
    let productionConnected = false;
    
    // Try direct connection first
    // For Supabase (both direct and pooler), we need to accept self-signed certificates
    const isSupabase = productionDbUrl.includes('supabase') || productionDbUrl.includes('pooler.supabase');
    productionPool = new Pool({ 
      connectionString: productionDbUrl,
      ssl: isSupabase ? { 
        rejectUnauthorized: false,
        require: true
      } : undefined
    });
    productionAdapter = new PrismaPg(productionPool);
    productionDb = new PrismaClient({
      adapter: productionAdapter,
      log: ['error'],
    });
    
    try {
      await productionDb.$connect();
      await productionDb.$queryRaw`SELECT 1`;
      console.log('✅ Production database connected (direct connection)\n');
      productionConnected = true;
    } catch (error: any) {
      console.warn('⚠️  Direct connection failed, trying connection pooler...');
      
      // Clean up failed direct connection
      try {
        await productionDb.$disconnect();
        await productionPool.end();
      } catch {}
      
      // Try pooler connection if direct connection fails
      if (productionDbUrl.includes('supabase')) {
        const poolerUrl = getPoolerUrl(productionDbUrl);
        console.log(`   Trying pooler: ${poolerUrl.replace(/:[^:@]+@/, ':****@')}`);
        
        productionPool = new Pool({ 
          connectionString: poolerUrl,
          ssl: { rejectUnauthorized: false }
        });
        productionAdapter = new PrismaPg(productionPool);
        productionDb = new PrismaClient({
          adapter: productionAdapter,
          log: ['error'],
        });
        
        try {
          await productionDb.$connect();
          await productionDb.$queryRaw`SELECT 1`;
          console.log('✅ Production database connected (via pooler)\n');
          console.log('⚠️  Note: Using connection pooler. Some operations may be limited.');
          console.log('   For best results, whitelist your IP and use direct connection (port 5432)\n');
          productionConnected = true;
        } catch (poolerError: any) {
          await productionDb.$disconnect();
          await productionPool.end();
          throw new Error(`Both direct and pooler connections failed. Direct: ${error.message}, Pooler: ${poolerError.message}`);
        }
      } else {
        throw error;
      }
    }
    
    if (!productionConnected) {
      console.error('❌ Failed to connect to production database');
      console.error('\n💡 Troubleshooting tips:');
      console.error('   1. Verify the connection string in .env.production');
      console.error('   2. Check if your IP is whitelisted in Supabase (Settings > Database > Connection Pooling)');
      console.error('   3. Ensure the database is not paused');
      console.error('   4. Try using the connection pooler URL (port 6543) instead of direct connection (port 5432)');
      throw new Error('Could not connect to production database');
    }

    // Run Prisma migrations on production database first
    // Always sync schema to ensure it matches the current schema.prisma file
    console.log('\n📋 Syncing production database schema...');
    console.log('   This will add missing columns and tables to match the current schema.');
    try {
      // Check if tables exist
      const tablesResult = await productionDb.$queryRaw<Array<{ tablename: string }>>`
        SELECT tablename FROM pg_tables WHERE schemaname = 'public'
      `;
      const existingTables = tablesResult.map(t => t.tablename);
      
      if (existingTables.length === 0) {
        console.log('   No tables found. Creating schema...');
      } else {
        console.log(`   Found ${existingTables.length} existing tables. Updating schema to match current schema...`);
      }
      
      // Always run db push to sync schema (adds missing columns/tables, doesn't remove data)
      try {
        console.log('   Running prisma db push to sync schema...');
        execSync('npx prisma db push --accept-data-loss', {
          stdio: 'inherit',
          env: { ...process.env, DATABASE_URL: productionDbUrl }
        });
        console.log('✅ Production database schema synced successfully\n');
      } catch (pushError: any) {
        console.warn('   ⚠️  db push failed:', pushError.message);
        console.warn('   ⚠️  Schema sync failed. Some data migrations may fail.');
        console.warn('   💡 Recommended: Run "npx prisma db push --accept-data-loss" manually with production DATABASE_URL');
        console.warn('   💡 Or use direct connection (port 5432) instead of pooler (port 6543)');
        console.warn('   💡 Continuing with data migration - schema mismatches will show as errors.\n');
        // Don't throw - continue with data migration even if schema sync failed
        // The errors will be more informative than stopping here
      }
    } catch (error: any) {
      console.warn('⚠️  Schema sync encountered issues:', error.message);
      console.warn('   Continuing with data migration - schema mismatches will show as errors.\n');
      // Don't throw - let migration continue
    }

    // 1. Users (no dependencies)
    await migrateTable(
      'user',
      () => deploymentDb.user.findMany(),
      (id) => productionDb.user.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.user.create({ data }),
      (data) => productionDb.user.update({ where: { id: data.id }, data })
    );

    // 2. Leagues (no dependencies)
    await migrateTable(
      'league',
      () => deploymentDb.league.findMany(),
      (id) => productionDb.league.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.league.create({ data }),
      (data) => productionDb.league.update({ where: { id: data.id }, data })
    );

    // 3. Seasons (depends on League)
    await migrateTable(
      'season',
      () => deploymentDb.season.findMany(),
      (id) => productionDb.season.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.season.create({ data }),
      (data) => productionDb.season.update({ where: { id: data.id }, data }),
      ['League']
    );

    // 4. Teams (no dependencies)
    await migrateTable(
      'team',
      () => deploymentDb.team.findMany(),
      (id) => productionDb.team.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.team.create({ data }),
      (data) => productionDb.team.update({ where: { id: data.id }, data })
    );

    // 5. Staff (no dependencies)
    await migrateTable(
      'staff',
      () => deploymentDb.staff.findMany(),
      (id) => productionDb.staff.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.staff.create({ data }),
      (data) => productionDb.staff.update({ where: { id: data.id }, data })
    );

    // 6. Players (depends on Team)
    await migrateTable(
      'player',
      () => deploymentDb.player.findMany(),
      (id) => productionDb.player.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.player.create({ data }),
      (data) => productionDb.player.update({ where: { id: data.id }, data }),
      ['Team']
    );

    // 7. TeamStaff (depends on Team and Staff)
    await migrateTable(
      'teamStaff',
      () => deploymentDb.teamStaff.findMany(),
      (id) => productionDb.teamStaff.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.teamStaff.create({ data }),
      (data) => productionDb.teamStaff.update({ where: { id: data.id }, data }),
      ['Team', 'Staff']
    );

    // 8. NewsArticles (depends on User)
    await migrateTable(
      'newsArticle',
      () => deploymentDb.newsArticle.findMany(),
      (id) => productionDb.newsArticle.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.newsArticle.create({ data }),
      (data) => productionDb.newsArticle.update({ where: { id: data.id }, data }),
      ['User']
    );

    // 9. Comments (depends on NewsArticle and User)
    await migrateTable(
      'comment',
      () => deploymentDb.comment.findMany(),
      (id) => productionDb.comment.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.comment.create({ data }),
      (data) => productionDb.comment.update({ where: { id: data.id }, data }),
      ['NewsArticle', 'User']
    );

    // 10. Matches (depends on League, Season, Team)
    await migrateTable(
      'match',
      () => deploymentDb.match.findMany(),
      (id) => productionDb.match.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.match.create({ data }),
      (data) => productionDb.match.update({ where: { id: data.id }, data }),
      ['League', 'Season', 'Team']
    );

    // 11. MatchPlayers (depends on Match, Player, Team)
    await migrateTable(
      'matchPlayer',
      () => deploymentDb.matchPlayer.findMany(),
      (id) => productionDb.matchPlayer.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.matchPlayer.create({ data }),
      (data) => productionDb.matchPlayer.update({ where: { id: data.id }, data }),
      ['Match', 'Player', 'Team']
    );

    // 12. MatchEvents (depends on Match, Player, Team)
    await migrateTable(
      'matchEvent',
      () => deploymentDb.matchEvent.findMany(),
      (id) => productionDb.matchEvent.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.matchEvent.create({ data }),
      (data) => productionDb.matchEvent.update({ where: { id: data.id }, data }),
      ['Match', 'Player', 'Team']
    );

    // 13. Media (no dependencies)
    await migrateTable(
      'media',
      () => deploymentDb.media.findMany(),
      (id) => productionDb.media.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.media.create({ data }),
      (data) => productionDb.media.update({ where: { id: data.id }, data })
    );

    // 14. PageContent (no dependencies)
    await migrateTable(
      'pageContent',
      () => deploymentDb.pageContent.findMany(),
      (id) => productionDb.pageContent.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.pageContent.create({ data }),
      (data) => productionDb.pageContent.update({ where: { id: data.id }, data })
    );

    // 15. SiteSetting (no dependencies)
    await migrateTable(
      'siteSetting',
      () => deploymentDb.siteSetting.findMany(),
      (id) => productionDb.siteSetting.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.siteSetting.create({ data }),
      (data) => productionDb.siteSetting.update({ where: { id: data.id }, data })
    );

    // 16. RegistrationNotifications (depends on Team, Player, Staff)
    await migrateTable(
      'registrationNotification',
      () => deploymentDb.registrationNotification.findMany(),
      (id) => productionDb.registrationNotification.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.registrationNotification.create({ data }),
      (data) => productionDb.registrationNotification.update({ where: { id: data.id }, data }),
      ['Team', 'Player', 'Staff']
    );

    // 17. GameRules (no dependencies)
    await migrateTable(
      'gameRules',
      () => deploymentDb.gameRules.findMany(),
      (id) => productionDb.gameRules.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.gameRules.create({ data }),
      (data) => productionDb.gameRules.update({ where: { id: data.id }, data })
    );

    // 18. ReportTemplate (no dependencies)
    await migrateTable(
      'reportTemplate',
      () => deploymentDb.reportTemplate.findMany(),
      (id) => productionDb.reportTemplate.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.reportTemplate.create({ data }),
      (data) => productionDb.reportTemplate.update({ where: { id: data.id }, data })
    );

    // 19. GameState (depends on Match)
    await migrateTable(
      'gameState',
      () => deploymentDb.gameState.findMany(),
      (id) => productionDb.gameState.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.gameState.create({ data }),
      (data) => productionDb.gameState.update({ where: { id: data.id }, data }),
      ['Match']
    );

    // 20. MatchPeriod (depends on Match)
    await migrateTable(
      'matchPeriod',
      () => deploymentDb.matchPeriod.findMany(),
      (id) => productionDb.matchPeriod.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.matchPeriod.create({ data }),
      (data) => productionDb.matchPeriod.update({ where: { id: data.id }, data }),
      ['Match']
    );

    // 21. Timeout (depends on Match, Team)
    await migrateTable(
      'timeout',
      () => deploymentDb.timeout.findMany(),
      (id) => productionDb.timeout.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.timeout.create({ data }),
      (data) => productionDb.timeout.update({ where: { id: data.id }, data }),
      ['Match', 'Team']
    );

    // 22. Substitution (depends on Match, Team, Player)
    await migrateTable(
      'substitution',
      () => deploymentDb.substitution.findMany(),
      (id) => productionDb.substitution.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.substitution.create({ data }),
      (data) => productionDb.substitution.update({ where: { id: data.id }, data }),
      ['Match', 'Team', 'Player']
    );

    // 23. PlayerPlayingTime (depends on MatchPlayer)
    await migrateTable(
      'playerPlayingTime',
      () => deploymentDb.playerPlayingTime.findMany(),
      (id) => productionDb.playerPlayingTime.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.playerPlayingTime.create({ data }),
      (data) => productionDb.playerPlayingTime.update({ where: { id: data.id }, data }),
      ['MatchPlayer']
    );

    // 24. JumpBall (depends on Match, Player, Team)
    await migrateTable(
      'jumpBall',
      () => deploymentDb.jumpBall.findMany(),
      (id) => productionDb.jumpBall.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.jumpBall.create({ data }),
      (data) => productionDb.jumpBall.update({ where: { id: data.id }, data }),
      ['Match', 'Player', 'Team']
    );

    // 25. EventHistory (depends on MatchEvent)
    await migrateTable(
      'eventHistory',
      () => deploymentDb.eventHistory.findMany(),
      (id) => productionDb.eventHistory.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.eventHistory.create({ data }),
      (data) => productionDb.eventHistory.update({ where: { id: data.id }, data }),
      ['MatchEvent']
    );

    // 26. ReportGeneration (depends on ReportTemplate)
    await migrateTable(
      'reportGeneration',
      () => deploymentDb.reportGeneration.findMany(),
      (id) => productionDb.reportGeneration.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.reportGeneration.create({ data }),
      (data) => productionDb.reportGeneration.update({ where: { id: data.id }, data }),
      ['ReportTemplate']
    );

    // 27. EmailReport (depends on ReportGeneration)
    await migrateTable(
      'emailReport',
      () => deploymentDb.emailReport.findMany(),
      (id) => productionDb.emailReport.findUnique({ where: { id } }).then(r => r || null),
      (data) => productionDb.emailReport.create({ data }),
      (data) => productionDb.emailReport.update({ where: { id: data.id }, data }),
      ['ReportGeneration']
    );

    // Print summary
    console.log('\n' + '='.repeat(60));
    console.log('📊 Migration Summary');
    console.log('='.repeat(60));
    console.log(`Users: ${stats.users}`);
    console.log(`Leagues: ${stats.leagues}`);
    console.log(`Seasons: ${stats.seasons}`);
    console.log(`Teams: ${stats.teams}`);
    console.log(`Staff: ${stats.staff}`);
    console.log(`Players: ${stats.players}`);
    console.log(`TeamStaff: ${stats.teamStaff}`);
    console.log(`NewsArticles: ${stats.newsArticles}`);
    console.log(`Comments: ${stats.comments}`);
    console.log(`Matches: ${stats.matches}`);
    console.log(`MatchPlayers: ${stats.matchPlayers}`);
    console.log(`MatchEvents: ${stats.matchEvents}`);
    console.log(`Media: ${stats.media}`);
    console.log(`PageContents: ${stats.pageContents}`);
    console.log(`SiteSettings: ${stats.siteSettings}`);
    console.log(`RegistrationNotifications: ${stats.registrationNotifications}`);
    console.log(`GameRules: ${stats.gameRules}`);
    console.log(`GameStates: ${stats.gameStates}`);
    console.log(`MatchPeriods: ${stats.matchPeriods}`);
    console.log(`Timeouts: ${stats.timeouts}`);
    console.log(`Substitutions: ${stats.substitutions}`);
    console.log(`PlayerPlayingTime: ${stats.playerPlayingTime}`);
    console.log(`JumpBalls: ${stats.jumpBalls}`);
    console.log(`EventHistory: ${stats.eventHistory}`);
    console.log(`ReportTemplates: ${stats.reportTemplates}`);
    console.log(`ReportGenerations: ${stats.reportGenerations}`);
    console.log(`EmailReports: ${stats.emailReports}`);
    console.log(`Errors: ${stats.errors}`);
    console.log('='.repeat(60));

    if (stats.errors > 0) {
      console.log('\n⚠️  Migration completed with errors. Please review the output above.');
    } else {
      console.log('\n✅ Migration completed successfully!');
    }

  } catch (error: any) {
    console.error('\n❌ Migration failed:', error.message);
    console.error(error);
    throw error;
  } finally {
    try {
      await deploymentDb.$disconnect();
    } catch {}
    try {
      await productionDb.$disconnect();
    } catch {}
    try {
      await deploymentPool.end();
    } catch {}
    try {
      await productionPool.end();
    } catch {}
    console.log('\n🔌 Disconnected from databases');
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });

